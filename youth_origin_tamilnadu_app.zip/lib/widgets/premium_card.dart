import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class PremiumCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const PremiumCard({super.key, required this.icon, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.gold.withOpacity(.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: AppTheme.green.withOpacity(.08),
            child: Icon(icon, color: AppTheme.green),
          ),
          const SizedBox(height: 15),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.black54)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
        ],
      ),
    );
  }
}
