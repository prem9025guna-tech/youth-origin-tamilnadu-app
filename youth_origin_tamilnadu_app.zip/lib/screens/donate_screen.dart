import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class DonateScreen extends StatelessWidget {
  const DonateScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Support Youth Origin')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Support community work', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
        const SizedBox(height: 12),
        const Text('Add your verified donation / UPI / payment-gateway details here before publishing the app.'),
        const SizedBox(height: 24),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
          child: const Column(children: [
            Icon(Icons.favorite_rounded, color: AppTheme.green, size: 42),
            SizedBox(height: 10),
            Text('Donation details', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            SizedBox(height: 6),
            Text('Configure your official payment details here.'),
          ]),
        ),
      ]),
    ),
  );
}
