import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class ProjectsScreen extends StatelessWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Projects & Activities')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        _Project(title: 'Youth Development', icon: Icons.groups),
        _Project(title: 'Community Development', icon: Icons.home_work_outlined),
        _Project(title: 'Education Initiatives', icon: Icons.school_outlined),
        _Project(title: 'Environmental Activities', icon: Icons.eco_outlined),
      ],
    ),
  );
}

class _Project extends StatelessWidget {
  final String title; final IconData icon;
  const _Project({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: AppTheme.gold.withOpacity(.18)),
    ),
    child: Row(children: [
      CircleAvatar(backgroundColor: AppTheme.green.withOpacity(.09), child: Icon(icon, color: AppTheme.green)),
      const SizedBox(width: 15),
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.darkGreen)),
    ]),
  );
}
