import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('About Us')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Youth Origin Tamilnadu', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
        const SizedBox(height: 12),
        const Text('இளைஞர்களின் எழுச்சி — தமிழ்நாட்டின் வளர்ச்சி!', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, height: 1.5)),
        const SizedBox(height: 20),
        _box('Vision', 'Empower young people to participate in meaningful community development.'),
        _box('Mission', 'Build youth-led initiatives around education, community development, environment and service.'),
        _box('Principle', 'வீழ்ந்தாலும்! — விதையாய் விழுவோம்!\nவளருமே! — மரமாய் எழுவோம்!'),
      ],
    ),
  );

  Widget _box(String title, String body) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: AppTheme.green, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text(body, style: const TextStyle(height: 1.5)),
    ]),
  );
}
