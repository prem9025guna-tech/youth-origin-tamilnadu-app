import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Profile')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            width: 92, height: 92,
            decoration: BoxDecoration(shape: BoxShape.circle, color: AppTheme.darkGreen),
            child: const Icon(Icons.person, color: AppTheme.gold, size: 46),
          ),
          const SizedBox(height: 16),
          const Text('Volunteer Profile', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
          const SizedBox(height: 8),
          const Text('Login and profile sync can be connected with Firebase Auth.'),
          const SizedBox(height: 24),
          _item(Icons.login, 'Login / Register'),
          _item(Icons.notifications_outlined, 'Notifications'),
          _item(Icons.settings_outlined, 'Settings'),
        ],
      ),
    ),
  );

  Widget _item(IconData icon, String title) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(17),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [
      Icon(icon, color: AppTheme.green),
      const SizedBox(width: 14),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
    ]),
  );
}
