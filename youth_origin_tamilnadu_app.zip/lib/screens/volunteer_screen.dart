import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../services/firebase_service.dart';

class VolunteerScreen extends StatefulWidget {
  const VolunteerScreen({super.key});

  @override
  State<VolunteerScreen> createState() => _VolunteerScreenState();
}

class _VolunteerScreenState extends State<VolunteerScreen> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final city = TextEditingController();
  bool loading = false;

  @override
  void dispose() {
    name.dispose(); phone.dispose(); email.dispose(); city.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => loading = true);
    try {
      await FirebaseService.submitVolunteer(
        name: name.text.trim(),
        phone: phone.text.trim(),
        email: email.text.trim(),
        city: city.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Volunteer registration submitted.')));
      formKey.currentState!.reset();
      name.clear(); phone.clear(); email.clear(); city.clear();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Firebase is not configured yet. Connect Firebase to save registrations.')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Volunteer Registration')),
    body: Form(
      key: formKey,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Join the movement.', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
          const SizedBox(height: 8),
          const Text('Be part of youth-led community development across Tamilnadu.'),
          const SizedBox(height: 24),
          _field(name, 'Full Name', Icons.person_outline),
          _field(phone, 'Phone Number', Icons.phone_outlined, keyboard: TextInputType.phone),
          _field(email, 'Email', Icons.email_outlined, keyboard: TextInputType.emailAddress),
          _field(city, 'City / District', Icons.location_on_outlined),
          const SizedBox(height: 10),
          SizedBox(
            height: 54,
            child: FilledButton(
              onPressed: loading ? null : submit,
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.green,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: loading ? const CircularProgressIndicator() : const Text('REGISTER AS VOLUNTEER', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    ),
  );

  Widget _field(TextEditingController controller, String label, IconData icon, {TextInputType? keyboard}) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: TextFormField(
      controller: controller,
      keyboardType: keyboard,
      validator: (v) => v == null || v.trim().isEmpty ? 'Please enter $label' : null,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    ),
  );
}
