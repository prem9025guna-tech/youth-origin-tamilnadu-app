import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme/app_theme.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  Future<void> call() async {
    final uri = Uri.parse('tel:+917305362825');
    await launchUrl(uri);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Contact Us')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        _contact(Icons.phone_outlined, 'Phone', '+91 73053 62825', call),
        _contact(Icons.email_outlined, 'Email', 'risetogetherfoundation14@gmail.com', () {}),
        _contact(Icons.location_on_outlined, 'Location', 'Tamilnadu, India', () {}),
      ]),
    ),
  );

  Widget _contact(IconData icon, String title, String value, VoidCallback action) => InkWell(
    onTap: action,
    child: Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Row(children: [
        CircleAvatar(backgroundColor: AppTheme.green.withOpacity(.09), child: Icon(icon, color: AppTheme.green)),
        const SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
          const SizedBox(height: 4),
          Text(value),
        ]),
      ]),
    ),
  );
}
