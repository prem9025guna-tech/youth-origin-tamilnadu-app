import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../widgets/premium_card.dart';
import 'about_screen.dart';
import 'gallery_screen.dart';
import 'announcements_screen.dart';
import 'donate_screen.dart';
import 'contact_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Youth Origin', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnnouncementsScreen())),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _hero(context),
            const SizedBox(height: 26),
            const Text('Make an Impact', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: PremiumCard(icon: Icons.groups_rounded, title: 'Volunteer', value: 'Join Us')),
              const SizedBox(width: 12),
              Expanded(child: PremiumCard(icon: Icons.event_rounded, title: 'Events', value: 'Explore')),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: PremiumCard(icon: Icons.photo_library_rounded, title: 'Gallery', value: 'View')),
              const SizedBox(width: 12),
              Expanded(child: PremiumCard(icon: Icons.favorite_rounded, title: 'Support', value: 'Donate')),
            ]),
            const SizedBox(height: 26),
            _quickLinks(context),
            const SizedBox(height: 26),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppTheme.darkGreen,
                borderRadius: BorderRadius.circular(26),
              ),
              child: const Column(
                children: [
                  Text('OUR PRINCIPLE', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900, letterSpacing: 2)),
                  SizedBox(height: 12),
                  Text(
                    'வீழ்ந்தாலும்! — விதையாய் விழுவோம்!\nவளருமே! — மரமாய் எழுவோம்!',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, height: 1.7),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hero(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(26),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [AppTheme.darkGreen, AppTheme.green]),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('YOUTH ORIGIN TAMILNADU', style: TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900, letterSpacing: 1.6)),
        const SizedBox(height: 12),
        const Text('Youth Rise.\nTamilnadu Grows.', style: TextStyle(color: Colors.white, fontSize: 32, height: 1.05, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Text('இளைஞர்களின் எழுச்சி — தமிழ்நாட்டின் வளர்ச்சி!', style: TextStyle(color: Colors.white.withOpacity(.88), fontSize: 15)),
        const SizedBox(height: 20),
        FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: AppTheme.gold,
            foregroundColor: AppTheme.darkGreen,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: () {},
          child: const Text('Become a Volunteer', style: TextStyle(fontWeight: FontWeight.w900)),
        ),
      ],
    ),
  );

  Widget _quickLinks(BuildContext context) => Wrap(
    spacing: 10,
    runSpacing: 10,
    children: [
      _chip(context, 'About Us', Icons.info_outline, const AboutScreen()),
      _chip(context, 'Gallery', Icons.photo_library_outlined, const GalleryScreen()),
      _chip(context, 'Announcements', Icons.campaign_outlined, const AnnouncementsScreen()),
      _chip(context, 'Donate', Icons.favorite_border, const DonateScreen()),
      _chip(context, 'Contact', Icons.call_outlined, const ContactScreen()),
    ],
  );

  Widget _chip(BuildContext context, String label, IconData icon, Widget page) => ActionChip(
    avatar: Icon(icon, size: 18, color: AppTheme.green),
    label: Text(label),
    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
  );
}
