import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class EventsScreen extends StatelessWidget {
  const EventsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Events')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        _EventCard(title: 'Youth Community Meet', date: 'Coming Soon', location: 'Tamilnadu'),
        _EventCard(title: 'Community Development Drive', date: 'Coming Soon', location: 'Tamilnadu'),
        _EventCard(title: 'Youth Origin Volunteer Meet', date: 'Coming Soon', location: 'Arakkonam'),
      ],
    ),
  );
}

class _EventCard extends StatelessWidget {
  final String title, date, location;
  const _EventCard({required this.title, required this.date, required this.location});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
    child: Row(
      children: [
        Container(
          width: 52, height: 52,
          decoration: BoxDecoration(color: AppTheme.green.withOpacity(.09), borderRadius: BorderRadius.circular(15)),
          child: const Icon(Icons.event, color: AppTheme.green),
        ),
        const SizedBox(width: 15),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
          const SizedBox(height: 5),
          Text('$date • $location', style: const TextStyle(color: Colors.black54)),
        ])),
      ],
    ),
  );
}
