import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Announcements')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        _Notice(title: 'Youth Origin Tamilnadu', body: 'Latest announcements will appear here.'),
        _Notice(title: 'Volunteer Updates', body: 'Volunteer opportunities and updates will be published here.'),
      ],
    ),
  );
}

class _Notice extends StatelessWidget {
  final String title, body;
  const _Notice({required this.title, required this.body});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
    child: Row(children: [
      const Icon(Icons.campaign_rounded, color: AppTheme.green),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.darkGreen)),
        const SizedBox(height: 5),
        Text(body),
      ])),
    ]),
  );
}
