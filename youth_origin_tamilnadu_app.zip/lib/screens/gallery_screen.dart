import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Gallery')),
    body: GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
      ),
      itemCount: 6,
      itemBuilder: (_, i) => Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppTheme.darkGreen, AppTheme.green]),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Center(child: Text('PHOTO ${i + 1}', style: const TextStyle(color: AppTheme.gold, fontWeight: FontWeight.w900))),
      ),
    ),
  );
}
