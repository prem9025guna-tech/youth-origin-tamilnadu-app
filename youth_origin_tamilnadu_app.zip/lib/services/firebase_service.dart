import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  static final _db = FirebaseFirestore.instance;

  static Future<void> submitVolunteer({
    required String name,
    required String phone,
    required String email,
    required String city,
  }) async {
    await _db.collection('volunteers').add({
      'name': name,
      'phone': phone,
      'email': email,
      'city': city,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'new',
    });
  }
}
