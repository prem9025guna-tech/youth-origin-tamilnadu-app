import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const green = Color(0xFF0B5D3B);
  static const darkGreen = Color(0xFF062C20);
  static const gold = Color(0xFFD6A84F);
  static const light = Color(0xFFF4FAF7);

  static ThemeData get light => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: light,
    colorScheme: ColorScheme.fromSeed(
      seedColor: green,
      primary: green,
      secondary: gold,
    ),
    textTheme: GoogleFonts.dmSansTextTheme(),
    appBarTheme: const AppBarTheme(
      backgroundColor: light,
      foregroundColor: darkGreen,
      elevation: 0,
      centerTitle: false,
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
      ),
    ),
  );
}
