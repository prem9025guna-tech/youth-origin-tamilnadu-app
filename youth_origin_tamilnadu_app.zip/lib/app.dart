import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'screens/splash_screen.dart';

class YouthOriginApp extends StatelessWidget {
  const YouthOriginApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Youth Origin Tamilnadu',
      theme: AppTheme.light,
      home: const SplashScreen(),
    );
  }
}
