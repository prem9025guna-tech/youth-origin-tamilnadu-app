# Youth Origin Tamilnadu

Premium Flutter starter app for Youth Origin Tamilnadu.

## Included
- Premium green/gold Material 3 UI
- Splash screen
- Home dashboard
- About, Volunteer, Events, Projects, Gallery, Announcements, Donate, Profile, Contact screens
- Bottom navigation
- Volunteer form UI
- Firebase-ready service layer
- Placeholder assets folders

## Run
1. Install Flutter.
2. Run `flutter pub get`.
3. Add Firebase configuration using FlutterFire if Firebase is needed.
4. Run `flutter run`.

Firebase is intentionally not hard-coded with project credentials.
